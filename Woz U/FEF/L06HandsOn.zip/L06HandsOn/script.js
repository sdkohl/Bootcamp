//navbar with four nav tabs or pills
//––one tab is a drop down menu
//add search box with glyphicon
$('.dropdown-toggle').dropdown()


//form with first name, last name, phone number, email



//table with three columns and four rows